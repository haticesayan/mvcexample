 <?php include('header.php'); ?>
    <div class="container">
    <h3>View All Guests</h3>
    <?php if($msg=$this->session->flashdata('msg')):?>
    <?php echo $msg; ?>
    <?php endif;?>
    <?php echo anchor('welcome/create', 'Add Guest',['class' => 'btn btn-primary']);?>
   <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Birthday</th>
      <th scope="col">Address</th>
      <th scope="col">TC</th>
      <th scope="col">Action</th>
      

     </tr>
  </thead>
  <tbody>
   <?php if(count($guests)):?>
   <?php foreach($guests as $guest): ?>
    <tr class="table-active">
     
      <td><?php echo $guest->fname?></td>
      <td><?php echo $guest->lname?></td>
      <td><?php echo $guest->birthday?></td>
      <td><?php echo $guest->address?></td>
      <td><?php echo $guest->tc?></td>
      <td>

        <?php echo anchor("welcome/update/{$guest->guest_id}", 'Update',['class' => 'badge badge-success']);?>   	
        <?php echo anchor("welcome/delete/{$guest->guest_id}", 'Delete',['class' => 'badge badge-danger']);?>
		 
      </td>
    </tr>
    <?php endforeach;?>
    <?php else: ?>
    <tr>
    	<td>No records Found!</td>
    </tr>
    <?php endif; ?>
    
  </tbody>
</table> 
</div>
<?php include('footer.php'); ?>
