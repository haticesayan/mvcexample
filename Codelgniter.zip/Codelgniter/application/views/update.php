<?php include('header.php'); ?>
<div class="container">
	<?php echo form_open('welcome/change', ['class'=>'form-horizantal']); ?>
  <fieldset>
    <legend>Update Stay Information</legend>

    <div class="form-group">
		<label for="chin_date">Check In Date</label>
    <div class="col-md-5">

            <?php echo form_input(['name' => 'chin_date','placeholder'=> 'Check In Date', 'class'=> 'form-control'
								   ]); ?>
	  </div>    
    <div class="col-md-5">
        <?php echo form_error('chin_date', '<div class="text-danger">', '</div');?>
    </div>
    	  </div>    
     <div class="form-group">
      <label for="chout_date">Check Out Date</label>
     <div class="col-md-5">
                  <?php echo form_input(['name' => 'chout_date','placeholder'=> 'Check Out Date', 'class'=> 'form-control']); ?>
    </div>
        <div class="col-md-5">
        <?php echo form_error('chout_date', '<div class="text-danger">', '</div');?>
    </div>
	  </div>
     <div class="form-group">
      <label for="type">Room Type</label>
     <div class="col-md-5">           
            <?php echo form_input(['name' => 'type','placeholder'=> 'Room Type', 'class'=> 'form-control']); ?>
    </div>
        <div class="col-md-5">
        <?php echo form_error('type', '<div class="text-danger">', '</div');?>
    </div>
	  </div>
     <div class="form-group">
      <label for="capacity">Capacity</label>
       <div class="col-md-5">         
            <?php echo form_input(['name' => 'capacity','placeholder'=> 'Capacity', 'class'=> 'form-control']); ?>
    </div>
      <div class="col-md-5">
        <?php echo form_error('capacity', '<div class="text-danger">', '</div');?>
    </div>
	  </div>
    <div class="form-group">
      <label for="price">Room Price</label> 
          <div class="col-md-5">                 
            <?php echo form_dropdown(['name'=>'price', 'options'=>['150$','200$','275$','350$'], 'selected'=>'0','class'=> 'form-control']); ?>
    </div>
	  </div>
    <div class="form-group">
       <label for="name">Room Name</label>
                <div class="col-md-5">
            <?php echo form_dropdown(['name'=>'name', 'options'=>['1','2','3','4'], 'selected'=>'0','class'=> 'form-control']); ?>
    </div>
	  </div>
     <legend>Update Guest Information</legend>

    <div class="form-group">
      <label for="fname">First Name</label>
     <div class="col-md-5">                 
                  <?php echo form_input(['id'=>'fname','name' => 'fname','placeholder'=> 'First Name', 'class'=> 'form-control',
									   'value'=>set_value('fname',$guest->fname)]); ?>  
    </div>
    <div class="col-md-5">
        <?php echo form_error('fname', '<div class="text-danger">', '</div');?>
    </div> 
	  </div>
     <div class="form-group">
      <label for="lname">Last Name</label>
        <div class="col-md-5">               
                   <?php echo form_input(['id'=>'lname','name' => 'lname','placeholder'=> 'Last Name', 'class'=> 'form-control',
										'value'=>set_value('lname',$guest->lname)]); ?>
    </div>
        <div class="col-md-5">
        <?php echo form_error('lname', '<div class="text-danger">', '</div');?>
    </div> 
	  </div>
     <div class="form-group">
      <label for="birthday">Birthday</label>
        <div class="col-md-5">               
                   <?php echo form_input(['id'=>'birthday','name' => 'birthday','placeholder'=> 'Birthday', 'class'=> 'form-control',
										'value'=>set_value('birthday',$guest->birthday)]); ?>             
    </div>
        <div class="col-md-5">
        <?php echo form_error('birthday', '<div class="text-danger">', '</div');?>
    </div>      
	  </div>
     <div class="form-group">
      <label for="address">Address</label>
         <div class="col-md-5">             
                  <?php echo form_input(['id'=>'address','name' => 'address','placeholder'=> 'Address', 'class'=> 'form-control',
									   'value'=>set_value('address',$guest->address)]); ?>
     </div>
         <div class="col-md-5">
        <?php echo form_error('address', '<div class="text-danger">', '</div');?>
    </div>
	  </div>
     <div class="form-group">
      <label for="tc">TC</label>
         <div class="col-md-5">            
                 <?php echo form_input(['id'=>'tc','name' => 'tc','placeholder'=> 'TC', 'class'=> 'form-control',
									  'value'=>set_value('tc',$guest->tc)]); ?>
       </div>
       <div class="col-md-5">
        <?php echo form_error('tc', '<div class="text-danger">', '</div');?>
    </div>
	  </div>
   <div class="form-group">
   
		 <?php echo form_submit(['name'=>'submit', 'value'=>'update', 'class'=>'btn btn-default']);?>
		 <?php echo anchor('welcome', 'Back', ['class'=>'btn btn-default']); ?>
		 </div>
		 
  </fieldset>
  <?php echo form_close();?>
</div>

<?php include('footer.php'); ?>