<?php
class queries extends CI_Model{
	

	
	public function getGuest(){
		
		$query = $this->db->get('guest');
		if($query->num_rows() > 0){
			return $query-> result();
		}

	}
	

	public function addG($data){
		
		return $this->db->insert('guest', $data);

	}	public function deleteGuest($guest_id){
		
		$this->db->where('guest_id', $guest_id);
        $this->db->delete('guest');


	}
	
	public function getSingleGuest($guest_id){
		
     $query = $this->db->get_where('guest', array('guest_id' => $guest_id));
		if($query->num_rows() > 0){
			return $query-> row();
		}}
		
	public function updateG($data,$id){
		return $this->db->delete('guest',['guest_id'=>$guest_id]);
		

	}
	
}
?>