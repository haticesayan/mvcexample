<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{   $this->load->model('queries');
	    $guests = $this->queries->getGuest();
		$this->load->view('welcome_message', ['guests'=>$guests]);
	}
	public function create()
	{
		$this->load->view('create');
	}

		public function delete($guest_id)
	{
		$this->load->model('queries');
	    if($this->queries->deleteGuest($guest_id)){
			
		$this->session->set_flashdata('msg','Deleted Successfully!');
			

		}
			else{
		$this->session->set_flashdata('msg','Failed to Delete!');
	
			}
			return redirect('welcome');
	}
	
	
		public function update($guest_id)
	{   $this->load->model('queries');
	    $guest = $this->queries->getSingleGuest($guest_id);
		$this->load->view('update',['guest'=>$guest]);
	}
	public function save(){


			  $this->form_validation->set_rules('fname', 'fname', 'required');
              $this->form_validation->set_rules('lname', 'lname', 'required');
              $this->form_validation->set_rules('address', 'address', 'required');
              $this->form_validation->set_rules('tc', 'tc', 'required');
		
 
                if ($this->form_validation->run())
                {
				   $data = array(
                   'fname' => $this->input->post('fname'),
                   'lname' => $this->input->post('lname'),
                   'birthday' => $this->input->post('birthday'),
                   'address' => $this->input->post('address'),
                   'tc' => $this->input->post('tc')
                   );

        $id = $this->db->insert('guest', $data);
				           $tc=$this->input->post('tc');  				
			
					
        if($id){$data2 = array(
                   'type' => $this->input->post('type'),
                   'capacity' => $this->input->post('capacity'),
                   'price' => $this->input->post('price'),
                   'name' => $this->input->post('name')
                   ); }
					
					$id2 = $this->db->insert('room', $data2);
					
                    }
					
                    if($id2){
						
					$name=$this->input->post('name');  				
				 
					$query = $this->db->query("SELECT room_id FROM ROOM where name ='$name'");

                    foreach($query->result_array() as $row){
                        $r1= $row['room_id'];
					}
		
						$data3 = array(
                   'chin_date' => $this->input->post('chin_date'),
                   'chout_date' => $this->input->post('chout_date'),
                   'payment' => $this->input->post('price'),
                   'room_fk' => $r1
					); }
                         $id3 = $this->db->insert('stay', $data3);
		
		
                    if($id3){
						
				    $query2 = $this->db->query("SELECT stay_id FROM STAY where room_fk ='$r1'");

                    foreach($query2->result_array() as $row2){
                        $r2= $row2['stay_id'];
					}
					$query5 = $this->db->query("SELECT guest_id FROM GUEST where tc ='$tc'");

                    foreach($query5->result_array() as $row5){
                        $r5= $row5['guest_id'];
					}	
						
						$data4 = array(
                   'guest_id' => $r5,
                   'stay_id' => $r2
					); }
                       $id4 = $this->db->insert('stayxguest', $data4);
		
                    if($id4){
					
                   $this->session->set_flashdata('msg','Saved Successfully!');
                                     $this->load->view('create');}
                     else{
				   $this->session->set_flashdata('msg','Failed to Save!');
					 }
	}

    public function change(){
		
		      $this->form_validation->set_rules('fname', 'fname', 'required');
              $this->form_validation->set_rules('lname', 'lname', 'required');
              $this->form_validation->set_rules('address', 'address', 'required');
              $this->form_validation->set_rules('tc', 'tc', 'required');
		
                if ($this->form_validation->run())
                {
				   $data = array(
                   'fname' => $this->input->post('fname'),
                   'lname' => $this->input->post('lname'),
                   'birthday' => $this->input->post('birthday'),
                   'address' => $this->input->post('address'),
                   'tc' => $this->input->post('tc')
                   );
		           $tc=$this->input->post('tc');  				

					
        $id = $this->db->where('tc', $tc)
			->update('guest',$data);
					
        if($id){$data2 = array(
                   'type' => $this->input->post('type'),
                   'capacity' => $this->input->post('capacity'),
                   'price' => $this->input->post('price'),
                   'name' => $this->input->post('name')
                   ); }
					
				    $name=$this->input->post('name');  				

					
					$id2 = $this->db->where('name', $name)
			->update('room',$data2);
					
                    }
                    if($id2){
						
					$name=$this->input->post('name');  				
				 
					$query3 = $this->db->query("SELECT room_id FROM ROOM where name ='$name'");

                    foreach($query3->result_array() as $row3){
                        $r3= $row3['room_id'];
					}
					$query4 = $this->db->query("SELECT stay_id FROM STAY where room_fk ='$r3'");

                    foreach($query4->result_array() as $row4){
                        $r4= $row4['stay_id'];
					}
						$data3 = array(
                   'chin_date' => $this->input->post('chin_date'),
                   'chout_date' => $this->input->post('chout_date'),
                   'payment' => $this->input->post('price'),
					); }
                         $id3 =  $this->db->where('stay_id', $r4)
			->update('stay',$data3);
                    if($id3){
					
                   $this->session->set_flashdata('msg','Uptaded Successfully!');
                                     $this->load->view('create');}
                     else{
				   $this->session->set_flashdata('msg','Failed to Update!');
					 }
		

	}




}
                

